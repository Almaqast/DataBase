﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using KP_prog_v._02.Project;
using static KP_prog_v._02.Interface;

namespace KP_prog_v._02.Project
{
    /// <summary>
    /// Логика взаимодействия для Add_Order.xaml
    /// </summary>
    public partial class Add_Order : Page
    {
        private C_Order _currentOrder;
        public Add_Order(C_Order selectOrder)
        {
            InitializeComponent();
            _currentOrder = new C_Order();
            _currentOrder.Order_number = 0;
            if (selectOrder != null)
            {
                _currentOrder = selectOrder;
            }
            DataContext = _currentOrder;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            int id;
            if (string.IsNullOrWhiteSpace(_currentOrder.Order_name))
            {
                errors.AppendLine("Укажите название приказа");
            }
            if (string.IsNullOrWhiteSpace(_currentOrder.Date_of_order))
            {
                errors.AppendLine("Укажите дату приказа");
            }

            if(errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if (_currentOrder.Order_number == 0)
            {
                if (COLLEGEEntities2.GetContext().C_Order.Count() == 0)
                {
                    _currentOrder.Order_number = 1;
                }
                else
                {
                    var rand = new Random();
                    id = rand.Next();
                    while (COLLEGEEntities2.GetContext().C_Order.FirstOrDefault(x => x.Order_number == id) != null)
                    {
                        id = rand.Next();
                    }
                    _currentOrder.Order_number = id;
                }
                COLLEGEEntities2.GetContext().C_Order.Add(_currentOrder);
            }
            else
            {
                id = _currentOrder.Order_number;
            }
            COLLEGEEntities2.GetContext().SaveChanges();
            MessageBox.Show("Информация сохранена");
            frame.GoBack(); 
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            frame.GoBack();
        }
    }
}
