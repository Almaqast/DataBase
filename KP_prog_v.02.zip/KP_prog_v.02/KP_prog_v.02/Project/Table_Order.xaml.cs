﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using KP_prog_v._02.Project;
using static KP_prog_v._02.Interface;

namespace KP_prog_v._02.Project
{
    /// <summary>
    /// Логика взаимодействия для Table_Order.xaml
    /// </summary>
    public partial class Table_Order : Page
    {
        public Table_Order()
        {
            InitializeComponent();
            Order.ItemsSource = COLLEGEEntities2.GetContext().C_Order.ToList();
        }
        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Table_selection());
        }
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Add_Order(null));
            Order.ItemsSource = COLLEGEEntities2.GetContext().C_Order.ToList();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var OrderRemoving = Order.SelectedItems.Cast<C_Order>().ToList();

            if (MessageBox.Show($"Вы точно хотите удалить следующее {OrderRemoving.Count()} элементов?", "Внимание",
               MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    COLLEGEEntities2.GetContext().C_Order.RemoveRange(OrderRemoving);
                    COLLEGEEntities2.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    Order.ItemsSource = COLLEGEEntities2.GetContext().C_Order.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Page_IsHitTestVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                COLLEGEEntities2.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                Order.ItemsSource = COLLEGEEntities2.GetContext().C_Order.ToList();
            }
        }

        private void btrEdit_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Add_Order((sender as Button).DataContext as C_Order));
        }
    }
}
