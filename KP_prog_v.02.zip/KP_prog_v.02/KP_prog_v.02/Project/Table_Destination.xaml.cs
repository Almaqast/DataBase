﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using KP_prog_v._02.Project;
using static KP_prog_v._02.Interface;

namespace KP_prog_v._02.Project
{
    /// <summary>
    /// Логика взаимодействия для Table_Destination.xaml
    /// </summary>
    public partial class Table_Destination : Page
    {
        public Table_Destination()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            frame.GoBack();
        }
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Add_Destination(null));
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var destinationRemoving = Destination.SelectedItems.Cast<Destination>().ToList();

            if (MessageBox.Show($"Вы точно хотите удалить следующее {destinationRemoving.Count()} элементов?", "Внимание",
               MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    COLLEGEEntities2.GetContext().Destination.RemoveRange(destinationRemoving);
                    COLLEGEEntities2.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    Destination.ItemsSource = COLLEGEEntities2.GetContext().Destination.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                COLLEGEEntities2.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                Destination.ItemsSource = COLLEGEEntities2.GetContext().Destination.ToList();
            }
        }

        private void btrEdit_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Add_Destination((sender as Button).DataContext as Destination));
        }
    }
}
