﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using KP_prog_v._02.Project;
using static KP_prog_v._02.Interface;

namespace KP_prog_v._02.Project
{
    /// <summary>
    /// Логика взаимодействия для Table_Staff.xaml
    /// </summary>
    public partial class Table_Staff : Page
    {
        int types;
        public Table_Staff()
        {
            InitializeComponent();
        }
        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Table_selection());
        }
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Add_Staff(null));
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var StaffRemoving = Staff.SelectedItems.Cast<Staff>().ToList();

            if (MessageBox.Show($"Вы точно хотите удалить следующее {StaffRemoving.Count()} элементов?", "Внимание",
               MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    COLLEGEEntities2.GetContext().Staff.RemoveRange(StaffRemoving);
                    COLLEGEEntities2.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    Staff.ItemsSource = COLLEGEEntities2.GetContext().Staff.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void btrEdit_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Add_Staff((sender as Button).DataContext as Staff));
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                COLLEGEEntities2.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                Staff.ItemsSource = COLLEGEEntities2.GetContext().Staff.ToList();
            }
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            if (sender is RadioButton r)
            {
                PolePoi.Visibility = Visibility.Visible;
                btnSearch.Visibility = Visibility.Visible;
                switch (r.Content)
                {
                    case "По фамилии":
                        Staff_info.Visibility = Visibility.Hidden; Staff_info.IsEnabled = false;
                        Staff_number.Visibility = Visibility.Visible; Staff_number.IsEnabled = true; //ciinfo
                        types = 1;

                        break;
                    case "По номеру":
                        Staff_number.Visibility = Visibility.Hidden; Staff_number.IsEnabled = false;
                        Staff_info.Visibility = Visibility.Visible; Staff_info.IsEnabled = true;
                        types = 0;
                        break;
                }
            }
        }
        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            if(PolePoi.Text != "")
            {
                switch (types)
                {
                    case 1:
                        StackPanel sp = new StackPanel();
                        foreach (KP_prog_v._02.Staff o in CE.Staff)  //  (kd2020.Owners o in AE.Owners)
                        {
                            if ((o.Secondname + " " + o.Name).Contains(PolePoi.Text))
                            {

                                RadioButton r = new RadioButton();
                                r.GroupName = "Staff";
                                r.Content = o.Secondname + "|" + o.Name + "|" + o.Surname + "|" + o.Status_job;
                                //r.Checked += CheckOwners;
                                sp.Children.Add(r);

                            }
                        }

                        Staff_number.Content = sp;
                        break;
                    case 0:
                        StackPanel sc = new StackPanel();
                        foreach (KP_prog_v._02.Staff o in CE.Staff)
                        {
                            if ((o.Staff_id == Convert.ToInt32(PolePoi.Text))||(o.Secondname == PolePoi.Text))
                            {

                                RadioButton r = new RadioButton();
                                r.GroupName = "Id";
                                r.Content = o.Staff_id + "|" + o.Secondname + "|" + o.Status_job;
                                //r.Checked += CheckCars;
                                sc.Children.Add(r);

                            }
                        }

                        Staff_info.Content = sc;
                        break;
                }
            }
            else
            {
                NavigationService.Navigate(new Table_Staff());

            }
        }
    }
}
