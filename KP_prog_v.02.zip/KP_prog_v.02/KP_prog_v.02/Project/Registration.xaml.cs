﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using KP_prog_v._02.Project;
using static KP_prog_v._02.Interface;

namespace KP_prog_v._02.Project
{
    /// <summary>
    /// Логика взаимодействия для Registration.xaml
    /// </summary>
    public partial class Registration : Page
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Loggin_in()); 
        }

        private void btnReg_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            int id = 0;
            Boolean b = false;
            List<C_Authorization> rols = CE.C_Authorization.ToList();
            foreach(C_Authorization r in rols)
            {
                if (r.Id_user > id)
                {
                    id = r.Id_user;
                }
                if(r.Login == loginR.Text && r.Password == pasR.Text)
                {
                    b = true;
                }
            }
            if(b)
            {
                MessageBox.Show("Пользователь зарегистрирован");
                frame.Content = new Loggin_in();
            }
            if (string.IsNullOrEmpty(secondnameR.Text))
            {
                errors.AppendLine("Укажите Фамилию");
            }
            if (string.IsNullOrEmpty(nameR.Text))
            {
                errors.AppendLine("Укажите Фамилию");
            }
            if (string.IsNullOrEmpty(surnameR.Text))
            {
                errors.AppendLine("Укажите Фамилию");
            }
            if (string.IsNullOrEmpty(phoneR.Text))
            {
                errors.AppendLine("Укажите Фамилию");
            }
            if (string.IsNullOrEmpty(loginR.Text))
            {
                errors.AppendLine("Укажите Фамилию");
            }
            if (string.IsNullOrEmpty(pasR.Text))
            {
                errors.AppendLine("Укажите Фамилию");
            }
            else
            {
                CE.C_Authorization.Add(new C_Authorization
                {
                    Id_user = id + 1,
                    Login = loginR.Text,
                    Password = pasR.Text,
                    Status = "Пользователь",
                    Name = nameR.Text,
                    Secondname = secondnameR.Text,
                    Surname = surnameR.Text,
                    Phone_number = phoneR.Text
                });
                CE.SaveChanges();
                Rol = "Пользователь";
                MessageBox.Show("Регистрация пользователя завершена");
                frame.Content = new Loggin_in();
            }
        }
    }
}
