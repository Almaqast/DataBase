﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using KP_prog_v._02.Project;
using static KP_prog_v._02.Interface;

namespace KP_prog_v._02.Project
{
    /// <summary>
    /// Логика взаимодействия для Add_Position.xaml
    /// </summary>
    public partial class Add_Position : Page
    {
        private Position _currentPosition;
        public Add_Position(Position selectPosition)
        {
            InitializeComponent();
            _currentPosition = new Position();
            _currentPosition.Job_number = 0;
            if (selectPosition != null)
            {
                _currentPosition = selectPosition;
            }
            DataContext = _currentPosition;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            int id;
            if (string.IsNullOrWhiteSpace(_currentPosition.Job_name))
            {
                errors.AppendLine("Укажите название должности");
            }

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if (_currentPosition.Job_number == 0)
            {
                if (COLLEGEEntities2.GetContext().Position.Count() == 0)
                {
                    _currentPosition.Job_number = 1;
                }
                else
                {
                    var rand = new Random();
                    id = rand.Next();
                    while (COLLEGEEntities2.GetContext().Position.FirstOrDefault(x => x.Job_number == id) != null)
                    {
                        id = rand.Next();
                    }
                    _currentPosition.Job_number = id;
                }
                COLLEGEEntities2.GetContext().Position.Add(_currentPosition);
            }
            else
            {
                id = _currentPosition.Job_number;
            }
            COLLEGEEntities2.GetContext().SaveChanges();
            MessageBox.Show("Информация сохранена");
            frame.GoBack();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            frame.GoBack();
        }
    }
}
