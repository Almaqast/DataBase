﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using KP_prog_v._02.Project;
using static KP_prog_v._02.Interface;

namespace KP_prog_v._02.Project
{
    /// <summary>
    /// Логика взаимодействия для Edit_Admin.xaml
    /// </summary>
    public partial class Edit_Admin : Page
    {
        private C_Authorization _currentAd;
        public Edit_Admin(C_Authorization selectAd)
        {
            InitializeComponent();
            _currentAd = new C_Authorization();
            _currentAd.Id_user = 0;
            if (selectAd != null)
            {
                _currentAd = selectAd;
            }
            DataContext = _currentAd;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            int id;
            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if (_currentAd.Id_user == 0)
            {
                if (COLLEGEEntities2.GetContext().C_Authorization.Count() == 0)
                {
                    _currentAd.Id_user = 1;
                }
                else
                {
                    var rand = new Random();
                    id = rand.Next();
                    while (COLLEGEEntities2.GetContext().C_Authorization.FirstOrDefault(x => x.Id_user == id) != null)
                    {
                        id = rand.Next();
                    }
                    _currentAd.Id_user = id;
                }
                COLLEGEEntities2.GetContext().C_Authorization.Add(_currentAd);
            }
            else
            {
                id = _currentAd.Id_user;
            }
            COLLEGEEntities2.GetContext().SaveChanges();
            MessageBox.Show("Информация сохранена");
            frame.GoBack();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            frame.GoBack();
        }
    }
}
