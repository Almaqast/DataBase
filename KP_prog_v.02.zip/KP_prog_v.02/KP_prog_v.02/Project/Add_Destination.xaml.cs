﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using KP_prog_v._02.Project;
using static KP_prog_v._02.Interface;

namespace KP_prog_v._02.Project
{
    /// <summary>
    /// Логика взаимодействия для Add_Destination.xaml
    /// </summary>
    public partial class Add_Destination : Page
    {
        private Destination _currentDestination;
        public Add_Destination(Destination selectDestination)
        {
            InitializeComponent();
            _currentDestination = new Destination();
            _currentDestination.Number = 0;
            if (selectDestination != null)
            {
                _currentDestination = selectDestination;
            }
            DataContext = _currentDestination;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            int id;
            //if (string.IsNullOrWhiteSpace(_currentDestination.))
            //{
            //    errors.AppendLine("Укажите название отдела");
            //}
            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if (_currentDestination.Number == 0)
            {
                if (COLLEGEEntities2.GetContext().Destination.Count() == 0)
                {
                    _currentDestination.Number = 1;
                }
                else
                {
                    var rand = new Random();
                    id = rand.Next();
                    while (COLLEGEEntities2.GetContext().Destination.FirstOrDefault(x => x.Number == id) != null)
                    {
                        id = rand.Next();
                    }
                    _currentDestination.Number = id;
                }
                COLLEGEEntities2.GetContext().Destination.Add(_currentDestination);
            }
            else
            {
                id = _currentDestination.Number;
            }
            COLLEGEEntities2.GetContext().SaveChanges();
            MessageBox.Show("Информация сохранена");
            frame.GoBack();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            frame.GoBack();
        }
    }
}
