﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using KP_prog_v._02.Project;
using static KP_prog_v._02.Interface;

namespace KP_prog_v._02.Project
{
    /// <summary>
    /// Логика взаимодействия для Table_user_Position.xaml
    /// </summary>
    public partial class Table_user_Position : Page
    {
        public Table_user_Position()
        {
            InitializeComponent();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                COLLEGEEntities2.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                Position.ItemsSource = COLLEGEEntities2.GetContext().Position.ToList();
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            frame.GoBack();
        }
    }
}
