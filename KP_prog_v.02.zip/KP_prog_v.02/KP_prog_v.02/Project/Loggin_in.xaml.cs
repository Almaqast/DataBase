﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;

using KP_prog_v._02.Project;
using static KP_prog_v._02.Interface;

namespace KP_prog_v._02.Project
{
    /// <summary>
    /// Логика взаимодействия для Loggin_in.xaml
    /// </summary>
    public partial class Loggin_in : Page
    {
        public Loggin_in()
        {
            InitializeComponent();
        }

        private void BtnEnter_Click(object sender, RoutedEventArgs e)
        {
            List<C_Authorization> Rols = CE.C_Authorization.ToList();
            foreach(C_Authorization r in Rols)
            {
                if(r.Login == Login.Text && r.Password == Password.Password)
                {
                    MessageBox.Show("Вход выполнен");
                    Rol = r.Status;
                    if(r.Status == "Администратор")
                    {
                        frame.Navigate(new Table_selection());
                    }
                    if(r.Status == "Пользователь")
                    {
                        frame.Navigate(new Table_selection_user());
                    }
                }
            }
        }
        private void BtnRegist_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Registration());
        }

        private void btnGuest_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Table_guests());
            //тут будет ссылка на новую таблицу, где будут указаны вакансии, их количесвто и название
        }
    }
}
