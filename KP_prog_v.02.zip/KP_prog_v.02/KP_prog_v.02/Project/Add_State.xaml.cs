﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using KP_prog_v._02.Project;
using static KP_prog_v._02.Interface;

namespace KP_prog_v._02.Project
{
    /// <summary>
    /// Логика взаимодействия для Add_State.xaml
    /// </summary>
    public partial class Add_State : Page
    {
        private C_State _currentState;
        public Add_State(C_State selectState)
        {
            InitializeComponent();
            _currentState = new C_State();
            _currentState.Department_number = 0;
            if (selectState != null)
            {
                _currentState = selectState;
            }
            DataContext = _currentState;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            int id;
            if (string.IsNullOrWhiteSpace(_currentState.Quantity))
            {
                errors.AppendLine("Укажите колличество мест");
            }

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if (_currentState.Job_number == 0 && _currentState.Department_number == 0)
            {
                if (COLLEGEEntities2.GetContext().C_State.Count() == 0)
                {
                    _currentState.Department_number = 1;
                    _currentState.Job_number = 1;
                }
                //else
                //{
                //    var rand = new Random();
                //    id = rand.Next();
                //    while (COLLEGEEntities3.GetContext().C_State.FirstOrDefault(x => x.Department_number == id) != null)
                //    {
                //        id = rand.Next();
                //    }
                //    _currentState.Department_number = id;
                //    _currentState.Job_number = id;
                //}
                COLLEGEEntities2.GetContext().C_State.Add(_currentState);
            }
            else
            {
                id = _currentState.Department_number;
                id = _currentState.Job_number;
            }
            COLLEGEEntities2.GetContext().SaveChanges();
            MessageBox.Show("Информация сохранена");
            frame.GoBack();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            frame.GoBack();
        }
    }
}
