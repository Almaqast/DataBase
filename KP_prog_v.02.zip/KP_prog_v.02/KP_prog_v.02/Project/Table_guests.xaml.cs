﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using KP_prog_v._02.Project;
using static KP_prog_v._02.Interface;

namespace KP_prog_v._02.Project
{
    /// <summary>
    /// Логика взаимодействия для Table_guests.xaml
    /// </summary>
    public partial class Table_guests : Page
    {
        public Table_guests()
        {
            InitializeComponent();
            //LoadData();
        }

        //private void LoadData()
        //{
        //    string ConnectionString = @"Data Source = DESKTOP-C2RTU4A\SQLEXPRESS; Initial Catalog = COLLEGE;" +
        //        "Integrated Security = True; Connect Timeout = 15; Encrypt = False;";

        //    string CmdString = string.Empty;
        //    using (SqlConnection connection = new SqlConnection(ConnectionString))
        //    {
        //        CmdString = "SELECT * FROM Table_guest";
        //        SqlCommand Cmd = new SqlCommand(CmdString, connection);
        //        SqlDataAdapter sda = new SqlDataAdapter(Cmd);

        //        DataSet ds = new DataSet("Table_guest");
        //        sda.Fill(ds);
        //        table_guest.ItemsSource = ds.Tables[0].DefaultView;
        //    }
        //}

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            frame.GoBack();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                COLLEGEEntities2.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                table_guest.ItemsSource = COLLEGEEntities2.GetContext().Table_guest.ToList();
            }
        }
    }
}
