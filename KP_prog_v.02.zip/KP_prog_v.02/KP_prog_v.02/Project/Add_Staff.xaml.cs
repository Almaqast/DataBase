﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using KP_prog_v._02.Project;
using static KP_prog_v._02.Interface;

namespace KP_prog_v._02.Project
{
    /// <summary>
    /// Логика взаимодействия для Add_Staff.xaml
    /// </summary>
    public partial class Add_Staff : Page
    {
        private Staff _currentStaff;
        public Add_Staff(Staff selectStaff)
        {
            InitializeComponent();
            _currentStaff = new Staff();
            _currentStaff.Staff_id = 0;
            if (selectStaff != null)
            {
                _currentStaff = selectStaff;
            }
            DataContext = _currentStaff;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            int id;
            if (string.IsNullOrWhiteSpace(_currentStaff.Secondname))
            {
                errors.AppendLine("Укажите фамилию");
            }
            if (string.IsNullOrWhiteSpace(_currentStaff.Name))
            {
                errors.AppendLine("Укажите Имя");
            }
            if (string.IsNullOrWhiteSpace(_currentStaff.Surname))
            {
                errors.AppendLine("Укажите отчество");
            }
            if (string.IsNullOrWhiteSpace(_currentStaff.Gender))
            {
                errors.AppendLine("Укажите пол");
            }
            if (string.IsNullOrWhiteSpace(_currentStaff.Date_of_Birth))
            {
                errors.AppendLine("Укажите дату рождения");
            }
            if (string.IsNullOrWhiteSpace(_currentStaff.Phone_number))
            {
                errors.AppendLine("Укажите номер телефона");
            }
            if (string.IsNullOrWhiteSpace(_currentStaff.Education))
            {
                errors.AppendLine("Укажите образование");
            }
            if (string.IsNullOrWhiteSpace(_currentStaff.Status_job))
            {
                errors.AppendLine("Укажите статус");
            }

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if (_currentStaff.Staff_id == 0)
            {
                if (COLLEGEEntities2.GetContext().Staff.Count() == 0)
                {
                    _currentStaff.Staff_id = 1;
                }
                else
                {
                    var rand = new Random();
                    id = rand.Next();
                    while (COLLEGEEntities2.GetContext().Staff.FirstOrDefault(x => x.Staff_id == id) != null)
                    {
                        id = rand.Next();
                    }
                    _currentStaff.Staff_id = id;
                }
                COLLEGEEntities2.GetContext().Staff.Add(_currentStaff);
            }
            else
            {
                id = _currentStaff.Staff_id;
            }
            COLLEGEEntities2.GetContext().SaveChanges();
            MessageBox.Show("Информация сохранена");
            frame.GoBack();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            frame.GoBack();
        }
    }
}
