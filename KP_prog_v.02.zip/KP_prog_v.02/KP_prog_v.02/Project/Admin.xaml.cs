﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using KP_prog_v._02.Project;
using static KP_prog_v._02.Interface;

namespace KP_prog_v._02.Project
{
    /// <summary>
    /// Логика взаимодействия для Admin.xaml
    /// </summary>
    public partial class Admin : Page
    {
        int types;
        public Admin()
        {
            InitializeComponent();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            COLLEGEEntities2.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
            Admins.ItemsSource = COLLEGEEntities2.GetContext().C_Authorization.ToList();
        }

        private void btrEdit_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Edit_Admin((sender as Button).DataContext as C_Authorization));
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Table_selection());
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var AdRemoving = Admins.SelectedItems.Cast<C_Authorization>().ToList();

            if (MessageBox.Show($"Вы точно хотите удалить следующее {AdRemoving.Count()} элементов?", "Внимание",
               MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    COLLEGEEntities2.GetContext().C_Authorization.RemoveRange(AdRemoving);
                    COLLEGEEntities2.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    Admins.ItemsSource = COLLEGEEntities2.GetContext().C_Authorization.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            COLLEGEEntities2.GetContext().SaveChanges();
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            if (sender is RadioButton r)
            {
                PolePoi.Visibility = Visibility.Visible;
                btnSearch.Visibility = Visibility.Visible;
                switch (r.Content)
                {
                    case "Поиск по фамилии":
                        Pol_name.Visibility = Visibility.Hidden; Pol_name.IsEnabled = false; //carInfo
                        Pol_number.Visibility = Visibility.Visible; Pol_number.IsEnabled = true; //ClInfo
                        types = 1;

                        break;
                    case "Поиск по номеру":
                        Pol_number.Visibility = Visibility.Hidden; Pol_number.IsEnabled = false;
                        Pol_name.Visibility = Visibility.Visible; Pol_name.IsEnabled = true;
                        types = 0;
                        break;
                }
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            if (PolePoi.Text != "")
            {
                switch (types)
                {
                    case 1:
                        StackPanel sp = new StackPanel();
                        foreach (KP_prog_v._02.C_Authorization o in CE.C_Authorization)
                        {
                            if (o.Secondname.Contains(PolePoi.Text))
                            {

                                RadioButton r = new RadioButton();
                                r.GroupName = "AdminId";
                                r.Content = o.Secondname + "|" + o.Name + "|" + o.Status;
                                //r.Checked += CheckOwners;
                                sp.Children.Add(r);

                            }
                        }

                        Pol_number.Content = sp;
                        break;

                    case 0:
                        StackPanel sc = new StackPanel();
                        foreach (KP_prog_v._02.C_Authorization o in CE.C_Authorization)
                        {
                            if (o.Id_user == Convert.ToInt32(PolePoi.Text))
                            {

                                RadioButton r = new RadioButton();
                                r.GroupName = "AdminN";
                                r.Content = o.Id_user + "|" + o.Secondname + "|" + o.Status;
                                //r.Checked += CheckCars;
                                sc.Children.Add(r);

                            }
                        }

                        Pol_name.Content = sc;
                        break;
                }
            }
            else
            {
                NavigationService.Navigate(new Admin());

            }
        }
    }
}
