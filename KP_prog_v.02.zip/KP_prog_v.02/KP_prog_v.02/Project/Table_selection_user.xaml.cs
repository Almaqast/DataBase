﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using KP_prog_v._02.Project;
using static KP_prog_v._02.Interface;

namespace KP_prog_v._02.Project
{
    /// <summary>
    /// Логика взаимодействия для Table_selection_user.xaml
    /// </summary>
    public partial class Table_selection_user : Page
    {
        public Table_selection_user()
        {
            InitializeComponent();
        }

        private void btnState_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Table_guests());
        }

        private void btnDepartment_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Table_User_Department());
        }

        private void btnPosition_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Table_user_Position());
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Loggin_in());
        }
    }
}
