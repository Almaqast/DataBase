﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using KP_prog_v._02.Project;
using static KP_prog_v._02.Interface;

namespace KP_prog_v._02.Project
{
    /// <summary>
    /// Логика взаимодействия для Table_Position.xaml
    /// </summary>
    public partial class Table_Position : Page
    {
        public Table_Position()
        {
            InitializeComponent();
        }
        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Table_selection());
        }
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Add_Position(null));
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var PositionRemoving = Position.SelectedItems.Cast<Position>().ToList();

            if (MessageBox.Show($"Вы точно хотите удалить следующее {PositionRemoving.Count()} элементов?", "Внимание",
               MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    COLLEGEEntities2.GetContext().Position.RemoveRange(PositionRemoving);
                    COLLEGEEntities2.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    Position.ItemsSource = COLLEGEEntities2.GetContext().Position.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void btrEdit_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(new Add_Position((sender as Button).DataContext as Position));
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                COLLEGEEntities2.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                Position.ItemsSource = COLLEGEEntities2.GetContext().Position.ToList();
            }
        }
    }
}
