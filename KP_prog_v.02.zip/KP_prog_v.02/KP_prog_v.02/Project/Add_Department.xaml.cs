﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using KP_prog_v._02.Project;
using static KP_prog_v._02.Interface;

namespace KP_prog_v._02.Project
{
    /// <summary>
    /// Логика взаимодействия для Add_Department.xaml
    /// </summary>
    public partial class Add_Department : Page
    {
        private Department _currentDepartment;
        public Add_Department(Department selectDepartment)
        {
            InitializeComponent();
            _currentDepartment = new Department();
            _currentDepartment.Department_number = 0;
            if(selectDepartment != null)
            {
                _currentDepartment = selectDepartment; 
            }
            DataContext = _currentDepartment;
            
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            int id;
            if (string.IsNullOrWhiteSpace(_currentDepartment.Department_name))
            {
                errors.AppendLine("Укажите название отдела");
            }

            if(errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if (_currentDepartment.Department_number == 0)
            {
                if (COLLEGEEntities2.GetContext().Department.Count() == 0)
                {
                    _currentDepartment.Department_number = 1;
                }
                else
                {
                    var rand = new Random();
                    id = rand.Next();
                    while (COLLEGEEntities2.GetContext().Department.FirstOrDefault(x => x.Department_number == id) != null)
                    {
                        id = rand.Next();
                    }
                    _currentDepartment.Department_number = id;
                }
                COLLEGEEntities2.GetContext().Department.Add(_currentDepartment);
            }
            else
            {
                id = _currentDepartment.Department_number;
            }
            COLLEGEEntities2.GetContext().SaveChanges();
            MessageBox.Show("Информация сохранена");
            frame.GoBack(); 
        }
        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            frame.GoBack();
        }
    }
    
}
