﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace KP_prog_v._02
{
    class Interface
    {
        public static COLLEGEEntities2 CE = new COLLEGEEntities2();
        public static Frame frame;
        public static string Rol;
    }
}
